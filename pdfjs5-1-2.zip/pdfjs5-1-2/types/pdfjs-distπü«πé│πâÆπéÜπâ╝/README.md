# Installation
> `npm install --save @types/pdfjs-dist`

# Summary
This package contains type definitions for PDF.js (https://github.com/mozilla/pdf.js).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/pdfjs-dist

Additional Details
 * Last updated: Mon, 12 Feb 2018 20:53:17 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by Josh Baldwin <https://github.com/jbaldwin>.
