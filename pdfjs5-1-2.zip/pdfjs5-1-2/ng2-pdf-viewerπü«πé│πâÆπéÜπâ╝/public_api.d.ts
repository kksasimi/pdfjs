export * from './src/app/pdf-viewer/pdf-viewer.module';
export * from './src/app/pdf-viewer/pdf-viewer.component';
